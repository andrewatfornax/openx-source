<?php

/*
+---------------------------------------------------------------------------+
| Revive Adserver                                                           |
| http://www.revive-adserver.com                                            |
|                                                                           |
| Copyright: See the COPYRIGHT.txt file.                                    |
| License: GPLv2 or later, see the LICENSE.txt file.                        |
+---------------------------------------------------------------------------+
*/

$conf = $GLOBALS['_MAX']['CONF'];

$words = array(
    'No Cookie Image Tag' => 'クッキーなしイメージタグ',
    'Allow No Cookie Image Tags' => 'クッキーなしイメージタグを許可する',

    'Third Party Comment' => '',
    'SSL Backup Comment' => '',
    'Comment' => '',
    
);

?>
